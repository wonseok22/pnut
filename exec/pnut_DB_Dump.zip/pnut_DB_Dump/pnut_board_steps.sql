-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: pnut.cr7lqn4qteql.ap-northeast-2.rds.amazonaws.com    Database: pnut
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `board_steps`
--

DROP TABLE IF EXISTS `board_steps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `board_steps` (
  `board_steps_id` bigint NOT NULL AUTO_INCREMENT,
  `board_id` bigint NOT NULL,
  `content` varchar(200) DEFAULT NULL,
  `image_url` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`board_steps_id`),
  KEY `fk_board_steps_board1_idx` (`board_id`),
  CONSTRAINT `board_steps_ibfk_1` FOREIGN KEY (`board_id`) REFERENCES `board` (`board_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=126 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `board_steps`
--

LOCK TABLES `board_steps` WRITE;
/*!40000 ALTER TABLE `board_steps` DISABLE KEYS */;
INSERT INTO `board_steps` VALUES (34,31,'대파를 송송 썰어요. ','9df998a8-c697-45f8-b729-bc5a58842111.jpg'),(35,31,'식용유에 대파를 볶아 파기름을 내고 같이 넣을 재료가 있으면 함께 볶아요(햄, 고기 등)','af1b586d-abaf-461a-922c-494cabbb3156.jpg'),(36,31,'설탕, 간장을 넣고 볶다가 살짝 눌은 냄새가 나면 김치를 넣어서 함께 볶아요','d41c7e0e-6baa-4b25-b97f-5a268a9ad177.jpg'),(37,31,'김치가 노릇노릇 익으면 밥을 넣고 볶아요. 달걀프라이와 김가루를 올리면 끝.','fd1f1161-3eef-4993-9b58-bd3089ecd3d0.jpg'),(38,32,'삼겹살을 비계부분과 옆부분을 시어링해주세요(구울 때 기름 닦아줘야 타지 않아요!)','1d3e9e1e-6c79-43e0-aa30-9a3856eb38d0.JPG'),(39,32,'냄비를 닦고 고기가 잠길 정도의 물에 고기와 대파, 생강 넣고 뚜껑 덮고 90분 끓여주기','8a3c1686-3a09-416d-aef9-688362493bec.JPG'),(40,32,'고기 빼고 다 버려주기',NULL),(41,32,'가쓰오부시 1.5리터 육수에 위에 준비한 양념 다 넣어주기','70c86743-c2a4-4866-bf43-01fb636c8f2b.JPG'),(42,32,'각지게 썬 고기를 잘 담아주고 90분 동안 졸여주기(종이포일로 덮어놓으면 덜 튀어요)',NULL),(81,44,'팬에 식용유를 두르고 마늘을 볶아요',NULL),(82,44,NULL,NULL),(83,44,'간장, 굴소스, 고추기름도 넣고 볶아요',NULL),(84,44,'우동을 삶고, 고명을 올려 마무리합니다.',NULL),(86,46,'팬에 식용유를 두르고 마늘을 볶아요',NULL),(87,46,'돼지고기 다짐육도 같이 넣고 볶아요',NULL),(88,46,'간장, 굴소스, 고추기름도 넣고 볶아요',NULL),(89,46,'우동을 삶고, 고명을 올려 마무리합니다.',NULL),(90,47,'JS를 섞는다',NULL),(91,47,'JS를 먹는다',NULL),(92,47,'훔',NULL),(93,47,'리스폰스타임',NULL),(94,48,'vscode를 켠다',NULL),(97,51,'vscode를켠다',NULL),(98,52,'라면 준비',NULL),(99,52,'물을 끓여요',NULL),(100,52,'맛있는 라면을 졸여요!',NULL),(101,52,'그럼 완성 이에용 >.<',NULL),(102,53,'팬에 식용유를 두르고 마늘을 볶아요',NULL),(103,53,'돼지고기 다짐육도 같이 넣고 볶아요',NULL),(104,53,'간장, 굴소스, 고추기름도 넣고 볶아요',NULL),(105,53,'우동을 삶고, 고명을 올려 마무리합니다.',NULL),(106,54,'팬에 식용유를 두르고 마늘을 볶아요',NULL),(107,54,'돼지고기 다짐육도 같이 넣고 볶아요',NULL),(108,55,'훔','0e67e203-59c9-49fc-9379-d934edf59db3.png'),(109,56,'고기준비.','cedd2981-9885-4a37-ae3e-a2daaa3c36f0.jpeg'),(110,56,'꾸워',NULL),(111,57,'2','1f45d9a6-6158-4ea3-880a-0206f7a753e9.png'),(112,58,'고기꾸어','65af74a7-e878-45a9-8463-818980effe7e.jpeg'),(113,59,'3Xz26610',NULL),(114,59,'우동면, 대파, 부추, 계란노른자, 다진 돼지고기, 김가루',NULL),(115,60,'345','478149ea-63d2-40a9-a612-f74f258617da.png'),(116,61,'VScode를 켠다','a4f1f3b0-38f3-42c8-a370-cba73524359f.png'),(117,61,'js코드를 마구 친다',NULL),(118,62,'35676',NULL),(119,63,'ㅁㄴㅇㄹ',NULL),(120,63,'ㅁㄴㅇㄻ',NULL),(121,64,'3245',NULL),(122,65,'',NULL),(123,65,NULL,NULL),(124,66,'',NULL),(125,66,NULL,NULL);
/*!40000 ALTER TABLE `board_steps` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-04-07  9:27:12
