-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: pnut.cr7lqn4qteql.ap-northeast-2.rds.amazonaws.com    Database: pnut
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `nut_quest`
--

DROP TABLE IF EXISTS `nut_quest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nut_quest` (
  `nut_quest_id` bigint NOT NULL AUTO_INCREMENT,
  `question_id` bigint NOT NULL,
  `nutrient_id` bigint NOT NULL,
  PRIMARY KEY (`nut_quest_id`),
  KEY `nut_quest_fk1_idx` (`nutrient_id`),
  KEY `nut_quest_fk2_idx` (`question_id`),
  CONSTRAINT `nut_quest_fk1` FOREIGN KEY (`nutrient_id`) REFERENCES `nutrient` (`nutrient_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `nut_quest_fk2` FOREIGN KEY (`question_id`) REFERENCES `question` (`question_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nut_quest`
--

LOCK TABLES `nut_quest` WRITE;
/*!40000 ALTER TABLE `nut_quest` DISABLE KEYS */;
INSERT INTO `nut_quest` VALUES (1,1,24),(2,2,13),(3,3,18),(4,3,19),(5,4,9),(6,5,16),(7,6,18),(8,7,8),(9,7,13),(10,8,20),(11,9,18),(12,9,7),(13,9,13),(14,10,17),(15,10,7),(16,11,18),(17,12,20),(18,13,4),(19,13,2),(20,13,3),(21,13,1),(22,14,18),(23,14,7),(24,14,2),(25,15,8),(26,16,6),(27,17,7),(28,17,17),(29,18,7),(30,18,17),(31,19,13),(32,20,20),(33,21,2),(34,21,18),(35,22,7),(36,22,9),(37,22,19),(38,23,18),(39,24,20),(40,25,9),(41,26,18),(42,26,20),(43,27,6),(44,27,16),(45,28,18),(46,29,2),(47,29,9),(48,30,2),(49,31,16),(50,32,13),(51,33,14),(52,34,10),(53,35,9),(54,36,20),(55,37,2),(56,38,20),(57,39,17),(58,40,13),(59,41,20),(60,41,17),(61,41,13);
/*!40000 ALTER TABLE `nut_quest` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-04-07  9:27:14
