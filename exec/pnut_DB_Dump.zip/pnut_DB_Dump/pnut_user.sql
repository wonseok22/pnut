-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: pnut.cr7lqn4qteql.ap-northeast-2.rds.amazonaws.com    Database: pnut
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `email` varchar(50) NOT NULL,
  `password` varchar(100) DEFAULT NULL,
  `salt` text,
  `nickname` varchar(24) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `type` varchar(10) DEFAULT NULL,
  `join_date` datetime DEFAULT NULL,
  `profile_image_url` varchar(100) DEFAULT NULL,
  `age` int NOT NULL,
  `gender` int NOT NULL,
  `refresh_token` varchar(255) DEFAULT NULL,
  `auth` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES ('2750seolhee@naver.com','a491e1eb582e2435257fe005d3ce52cad7dca55111b6e83906ea060b173734fd','spvsHKe6sCafoKO7ZNTdTA==','설히','김설희','default','2023-04-06 20:09:04','5e72feee-bcd6-402c-b0d7-e0cf66b7ca2d.png',24,1,NULL,''),('admin@ssafy.com','d29be45d5b9739846d9d6185a2f8384f5d13b1f962a5af1a6a0c35cc6bf045f7','A6v2jrKdDX1DIq8xUnB2nQ==','admin123','admin','default','2023-03-20 15:55:53','basic_profile_image_37d8I092LMX89-removebg-preview.png',26,0,NULL,'auth'),('cavalier7@naver.com','6fbb681ca1019b670251d8fd7078dabfcfe033e29f292f8ce7dcc1608bf77a48','M/RTusbK2mns/MDZWSRQrQ==','7반컨','고성현','default','2023-04-06 10:41:50','basic_profile_image_37d8I092LMX89-removebg-preview.png',46,0,'eyJ0eXAiOiJKV1QiLCJyZWdEYXRlIjoxNjgwNzQ1MzM5NzQ4LCJhbGciOiJIUzI1NiJ9.eyJleHAiOjE2ODE5NTQ5MzksInN1YiI6InJlZnJlc2gtdG9rZW4iLCJlbWFpbCI6ImNhdmFsaWVyN0BuYXZlci5jb20ifQ.6WzkKNc9P35zJH3tCNwPNjFuZbzz-bha35Ub9CV5ZOU',''),('gkagu12@naver.com','d3e140995036f996d8d98f1c312a694f76127678d09e7e607753e10bc590ca7c','gWjdsBapUv8oLftutLzRtA==','Ham','jun','default','2023-04-03 16:05:48','e7b6234b-cdad-4d52-a78b-2a17917c1453.JPG',7,0,'eyJ0eXAiOiJKV1QiLCJyZWdEYXRlIjoxNjgwODAyNzk4NzAwLCJhbGciOiJIUzI1NiJ9.eyJleHAiOjE2ODIwMTIzOTgsInN1YiI6InJlZnJlc2gtdG9rZW4iLCJlbWFpbCI6ImdrYWd1MTJAbmF2ZXIuY29tIn0.OBhyLjcxjdXHmS9ivsYZI_6HmHjCfbR0Qc61uBUPqW0',''),('jleejlee6@gmail.com','e3c4a56343281af59c08e93659924050380b21e8a33c6a4f149a6da8e84b9540','TccrM5LwDoHF3qBf51lv6g==','나한원석아니다','한원석','default','2023-04-06 13:44:30','d17fa362-061d-48b6-8a27-f88751d6d9d1.jpg',5,1,'eyJ0eXAiOiJKV1QiLCJyZWdEYXRlIjoxNjgwNzg5NTM4Njk2LCJhbGciOiJIUzI1NiJ9.eyJleHAiOjE2ODE5OTkxMzgsInN1YiI6InJlZnJlc2gtdG9rZW4iLCJlbWFpbCI6ImpsZWVqbGVlNkBnbWFpbC5jb20ifQ.9SX27R46yi6p-F5MlaWOMJOHZ0mmPYNqeiOTkCe9DkY',''),('minofficial@naver.com','efccd12a7cce703edcbb76995acdf5e745d8a66be7d7ae71d7fc8ed0b2865495','qTNXHlB38qmGEkU3QbSmqA==','콩이','김민경','default','2023-04-07 00:50:56','e3607a5b-e9c1-4d77-aae0-387513d58531.jpg',25,1,'eyJ0eXAiOiJKV1QiLCJyZWdEYXRlIjoxNjgwODI0NjcxNjUyLCJhbGciOiJIUzI1NiJ9.eyJleHAiOjE2ODIwMzQyNzEsInN1YiI6InJlZnJlc2gtdG9rZW4iLCJlbWFpbCI6Im1pbm9mZmljaWFsQG5hdmVyLmNvbSJ9.slt3jbGYVssTYkaRwoJYwzIiFsFGHCgxHEpYVgdQybw',''),('minofficial13@gmail.com','1c91ed08d215c61def06152b4485f20bf3ac64534595c5728c3c6bccdbd2c490','BwfdaN7n4RBSbDjBYHzB1Q==','kongee','김민경','default','2023-04-06 12:40:22','kongee',25,1,NULL,''),('tayoun011@naver.com','bafb312a41bf7ecfc823217b75042a0fb9fd14e4d19a6f598123cc65a462cef2','qFYMlHQCPsHgFM5F0eQJlg==','영차영차앵차','안태윤','default','2023-04-06 09:30:43','basic_profile_image_37d8I092LMX89-removebg-preview.png',26,0,'eyJ0eXAiOiJKV1QiLCJyZWdEYXRlIjoxNjgwNzQxMDQ3Mjg2LCJhbGciOiJIUzI1NiJ9.eyJleHAiOjE2ODE5NTA2NDcsInN1YiI6InJlZnJlc2gtdG9rZW4iLCJlbWFpbCI6InRheW91bjAxMUBuYXZlci5jb20ifQ.JvE5Iy1T8jkJHY6poGt4rpvfREZ-YRUxaZvT5OcM1VQ',''),('tlsdnrng@gmail.com','f9da3fa93f442f2be37a7a4a1aa644f7acabd7267860c439e592330010f93116','zwjwHANIkoR5qx8mU3hIQA==','싱욱','강신욱','default','2023-03-31 17:23:55','basic_profile_image_37d8I092LMX89-removebg-preview.png',6,0,NULL,''),('withfavor98@naver.com','b31e10945d5f68291614ad0d90ba37cb4d7d3b98bb237a8c1596878255d21b4d','Tf/O8ttRbztVR0zLwgmLVA==','재링','최재희','default','2023-04-04 10:05:21','ba63e2dc-b90f-4193-8a26-e0cf59b2c69d.png',24,1,'eyJ0eXAiOiJKV1QiLCJyZWdEYXRlIjoxNjgwNzk5ODk2NDk1LCJhbGciOiJIUzI1NiJ9.eyJleHAiOjE2ODIwMDk0OTYsInN1YiI6InJlZnJlc2gtdG9rZW4iLCJlbWFpbCI6IndpdGhmYXZvcjk4QG5hdmVyLmNvbSJ9.EGI4GQs6GRr5gk5pl7SMyZ_FeO-QvgFpb2zIY0fMLGE',''),('zacinthepark@gmail.com','df812848c04f7f97f4b9efe4538532568257a282dc84b0cd16e5824b439f44dc','FoZ1ru9rOcjGdtcbt+/OSw==','지누지누션','박진우','default','2023-04-06 23:30:41','9aafedac-9e62-4c29-8edf-d70db90ee795.jpg',10,0,'eyJ0eXAiOiJKV1QiLCJyZWdEYXRlIjoxNjgwODI1OTgyMTMzLCJhbGciOiJIUzI1NiJ9.eyJleHAiOjE2ODIwMzU1ODIsInN1YiI6InJlZnJlc2gtdG9rZW4iLCJlbWFpbCI6InphY2ludGhlcGFya0BnbWFpbC5jb20ifQ.WQCi1H23ai0IeNrJMb3CEp5BfxRkNp4CbofYaHRDcdA','');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-04-07  9:27:10
