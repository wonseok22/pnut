-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: pnut.cr7lqn4qteql.ap-northeast-2.rds.amazonaws.com    Database: pnut
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `user_symptom`
--

DROP TABLE IF EXISTS `user_symptom`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_symptom` (
  `user_symptom_id` bigint NOT NULL AUTO_INCREMENT,
  `user_email` varchar(50) NOT NULL,
  `nutrient_id` bigint NOT NULL,
  `value` float DEFAULT NULL,
  PRIMARY KEY (`user_symptom_id`),
  KEY `fk_user_symptom_user1_idx` (`user_email`),
  KEY `fk_user_symptom_nutrient1_idx` (`nutrient_id`),
  CONSTRAINT `fk_user_symptom_nutrient1` FOREIGN KEY (`nutrient_id`) REFERENCES `nutrient` (`nutrient_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_user_symptom_user1` FOREIGN KEY (`user_email`) REFERENCES `user` (`email`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=568 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_symptom`
--

LOCK TABLES `user_symptom` WRITE;
/*!40000 ALTER TABLE `user_symptom` DISABLE KEYS */;
INSERT INTO `user_symptom` VALUES (172,'withfavor98@naver.com',7,0.75),(173,'withfavor98@naver.com',7,0.75),(174,'withfavor98@naver.com',8,0.25),(175,'withfavor98@naver.com',8,0.25),(176,'withfavor98@naver.com',9,0.25),(177,'withfavor98@naver.com',7,0.75),(178,'withfavor98@naver.com',9,0.25),(179,'withfavor98@naver.com',8,0.25),(180,'withfavor98@naver.com',13,1),(181,'withfavor98@naver.com',9,0.25),(182,'withfavor98@naver.com',13,1),(183,'withfavor98@naver.com',16,0.25),(184,'withfavor98@naver.com',16,0.25),(185,'withfavor98@naver.com',13,1),(186,'withfavor98@naver.com',17,0.5),(187,'withfavor98@naver.com',17,0.5),(188,'withfavor98@naver.com',18,1.5),(189,'withfavor98@naver.com',16,0.25),(190,'withfavor98@naver.com',18,1.5),(191,'withfavor98@naver.com',19,0.5),(192,'withfavor98@naver.com',19,0.5),(193,'withfavor98@naver.com',17,0.5),(194,'withfavor98@naver.com',20,0.5),(195,'withfavor98@naver.com',18,1.5),(196,'withfavor98@naver.com',20,0.5),(197,'withfavor98@naver.com',24,0.25),(198,'withfavor98@naver.com',19,0.5),(199,'withfavor98@naver.com',24,0.25),(200,'withfavor98@naver.com',20,0.5),(201,'withfavor98@naver.com',24,0.25),(311,'tlsdnrng@gmail.com',9,0.75),(312,'tlsdnrng@gmail.com',13,1),(313,'tlsdnrng@gmail.com',17,0.5),(314,'tlsdnrng@gmail.com',18,0.5),(315,'tlsdnrng@gmail.com',19,0.5),(316,'tlsdnrng@gmail.com',20,0.75),(317,'tlsdnrng@gmail.com',24,0.5),(488,'cavalier7@naver.com',2,1.5),(489,'cavalier7@naver.com',6,0.25),(490,'cavalier7@naver.com',7,1),(491,'cavalier7@naver.com',9,0.75),(492,'cavalier7@naver.com',10,0.25),(493,'cavalier7@naver.com',13,0.25),(494,'cavalier7@naver.com',14,0.25),(495,'cavalier7@naver.com',16,0.25),(496,'cavalier7@naver.com',18,1.25),(497,'cavalier7@naver.com',19,0.25),(498,'cavalier7@naver.com',20,0.25),(499,'tayoun011@naver.com',7,0.5),(500,'tayoun011@naver.com',16,0.5),(501,'tayoun011@naver.com',17,0.5),(502,'tayoun011@naver.com',20,1.75),(516,'admin@ssafy.com',1,0.25),(517,'admin@ssafy.com',2,0.75),(518,'admin@ssafy.com',3,0.25),(519,'admin@ssafy.com',4,0.25),(520,'admin@ssafy.com',6,0.25),(521,'admin@ssafy.com',7,0.5),(522,'admin@ssafy.com',8,0.25),(523,'admin@ssafy.com',9,0.75),(524,'admin@ssafy.com',13,0.25),(525,'admin@ssafy.com',18,1),(526,'admin@ssafy.com',19,0.5),(527,'admin@ssafy.com',20,0.25),(528,'admin@ssafy.com',24,0.25),(529,'2750seolhee@naver.com',1,0.75),(530,'2750seolhee@naver.com',2,1.5),(531,'2750seolhee@naver.com',3,0.75),(532,'2750seolhee@naver.com',4,0.75),(533,'2750seolhee@naver.com',6,0.75),(534,'2750seolhee@naver.com',7,1.5),(535,'2750seolhee@naver.com',8,1.5),(536,'2750seolhee@naver.com',13,2.75),(537,'2750seolhee@naver.com',16,0.75),(538,'2750seolhee@naver.com',17,0.5),(539,'2750seolhee@naver.com',18,2.25),(540,'2750seolhee@naver.com',20,1.25),(541,'minofficial13@gmail.com',1,0.75),(542,'minofficial13@gmail.com',2,0.75),(543,'minofficial13@gmail.com',3,0.75),(544,'minofficial13@gmail.com',4,0.75),(545,'minofficial13@gmail.com',7,1.5),(546,'minofficial13@gmail.com',8,1),(547,'minofficial13@gmail.com',13,1.5),(548,'minofficial13@gmail.com',16,0.5),(549,'minofficial13@gmail.com',17,1),(550,'minofficial13@gmail.com',18,1.25),(551,'zacinthepark@gmail.com',2,0.75),(552,'zacinthepark@gmail.com',7,0.5),(553,'zacinthepark@gmail.com',8,0.5),(554,'zacinthepark@gmail.com',9,0.5),(555,'zacinthepark@gmail.com',13,0.5),(556,'zacinthepark@gmail.com',16,0.5),(557,'zacinthepark@gmail.com',18,1.25),(558,'zacinthepark@gmail.com',19,0.5),(559,'zacinthepark@gmail.com',20,1.75),(560,'minofficial@naver.com',2,0.25),(561,'minofficial@naver.com',7,0.75),(562,'minofficial@naver.com',9,0.5),(563,'minofficial@naver.com',13,0.25),(564,'minofficial@naver.com',17,0.5),(565,'minofficial@naver.com',18,0.75),(566,'minofficial@naver.com',19,0.25),(567,'minofficial@naver.com',20,0.75);
/*!40000 ALTER TABLE `user_symptom` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-04-07  9:27:14
