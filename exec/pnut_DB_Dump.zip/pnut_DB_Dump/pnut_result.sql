-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: pnut.cr7lqn4qteql.ap-northeast-2.rds.amazonaws.com    Database: pnut
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `result`
--

DROP TABLE IF EXISTS `result`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `result` (
  `result_id` bigint NOT NULL AUTO_INCREMENT,
  `user_email` varchar(50) NOT NULL,
  `question_id` bigint NOT NULL,
  `degree` int DEFAULT NULL,
  PRIMARY KEY (`result_id`),
  KEY `fk_result_question1_idx` (`question_id`),
  KEY `fk_result_user1` (`user_email`),
  CONSTRAINT `fk_result_question1` FOREIGN KEY (`question_id`) REFERENCES `question` (`question_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_result_user1` FOREIGN KEY (`user_email`) REFERENCES `user` (`email`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=358 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `result`
--

LOCK TABLES `result` WRITE;
/*!40000 ALTER TABLE `result` DISABLE KEYS */;
INSERT INTO `result` VALUES (113,'withfavor98@naver.com',10,2),(114,'withfavor98@naver.com',5,1),(115,'withfavor98@naver.com',1,1),(116,'withfavor98@naver.com',6,2),(117,'withfavor98@naver.com',11,1),(118,'withfavor98@naver.com',2,2),(119,'withfavor98@naver.com',7,1),(120,'withfavor98@naver.com',12,1),(121,'withfavor98@naver.com',3,2),(122,'withfavor98@naver.com',8,1),(123,'withfavor98@naver.com',4,1),(124,'withfavor98@naver.com',9,1),(251,'tlsdnrng@gmail.com',1,2),(252,'tlsdnrng@gmail.com',38,2),(254,'tlsdnrng@gmail.com',2,1),(255,'tlsdnrng@gmail.com',39,1),(257,'tlsdnrng@gmail.com',3,2),(258,'tlsdnrng@gmail.com',40,2),(260,'tlsdnrng@gmail.com',4,3),(261,'tlsdnrng@gmail.com',41,1),(268,'tlsdnrng@gmail.com',26,0),(269,'cavalier7@naver.com',13,0),(270,'cavalier7@naver.com',21,1),(271,'cavalier7@naver.com',29,1),(272,'cavalier7@naver.com',14,3),(273,'cavalier7@naver.com',22,1),(274,'cavalier7@naver.com',30,1),(275,'cavalier7@naver.com',15,0),(276,'cavalier7@naver.com',31,1),(277,'cavalier7@naver.com',23,1),(278,'cavalier7@naver.com',16,1),(279,'cavalier7@naver.com',24,1),(280,'cavalier7@naver.com',32,1),(281,'cavalier7@naver.com',33,1),(282,'cavalier7@naver.com',25,1),(283,'cavalier7@naver.com',34,1),(284,'tayoun011@naver.com',10,2),(285,'tayoun011@naver.com',17,0),(286,'tayoun011@naver.com',5,2),(287,'tayoun011@naver.com',11,0),(288,'tayoun011@naver.com',18,0),(289,'tayoun011@naver.com',6,0),(290,'tayoun011@naver.com',12,1),(291,'tayoun011@naver.com',19,0),(292,'tayoun011@naver.com',7,0),(293,'tayoun011@naver.com',20,3),(294,'tayoun011@naver.com',8,3),(295,'tayoun011@naver.com',9,0),(296,'admin@ssafy.com',13,1),(297,'admin@ssafy.com',14,1),(298,'admin@ssafy.com',21,1),(299,'admin@ssafy.com',22,1),(300,'admin@ssafy.com',15,1),(301,'admin@ssafy.com',23,1),(302,'admin@ssafy.com',16,1),(303,'admin@ssafy.com',24,1),(304,'admin@ssafy.com',25,1),(305,'admin@ssafy.com',1,1),(306,'admin@ssafy.com',2,1),(307,'admin@ssafy.com',3,1),(308,'admin@ssafy.com',4,1),(309,'2750seolhee@naver.com',5,3),(310,'2750seolhee@naver.com',38,0),(311,'2750seolhee@naver.com',13,3),(312,'2750seolhee@naver.com',14,3),(313,'2750seolhee@naver.com',39,0),(314,'2750seolhee@naver.com',6,3),(315,'2750seolhee@naver.com',15,3),(316,'2750seolhee@naver.com',40,3),(317,'2750seolhee@naver.com',7,3),(318,'2750seolhee@naver.com',16,3),(319,'2750seolhee@naver.com',41,2),(320,'2750seolhee@naver.com',8,3),(321,'2750seolhee@naver.com',9,3),(322,'minofficial13@gmail.com',5,2),(323,'minofficial13@gmail.com',17,2),(324,'minofficial13@gmail.com',13,3),(325,'minofficial13@gmail.com',6,3),(326,'minofficial13@gmail.com',18,2),(327,'minofficial13@gmail.com',14,0),(328,'minofficial13@gmail.com',7,2),(329,'minofficial13@gmail.com',15,2),(330,'minofficial13@gmail.com',19,2),(331,'minofficial13@gmail.com',8,0),(332,'minofficial13@gmail.com',16,0),(333,'minofficial13@gmail.com',20,0),(334,'minofficial13@gmail.com',9,2),(335,'zacinthepark@gmail.com',21,2),(336,'zacinthepark@gmail.com',5,2),(337,'zacinthepark@gmail.com',35,0),(338,'zacinthepark@gmail.com',6,2),(339,'zacinthepark@gmail.com',22,2),(340,'zacinthepark@gmail.com',36,2),(341,'zacinthepark@gmail.com',7,2),(342,'zacinthepark@gmail.com',23,1),(343,'zacinthepark@gmail.com',37,1),(344,'zacinthepark@gmail.com',8,3),(345,'zacinthepark@gmail.com',24,2),(346,'zacinthepark@gmail.com',9,0),(347,'zacinthepark@gmail.com',25,0),(348,'minofficial@naver.com',26,1),(349,'minofficial@naver.com',21,1),(350,'minofficial@naver.com',17,1),(351,'minofficial@naver.com',18,1),(352,'minofficial@naver.com',22,1),(353,'minofficial@naver.com',19,1),(354,'minofficial@naver.com',23,1),(355,'minofficial@naver.com',20,1),(356,'minofficial@naver.com',24,1),(357,'minofficial@naver.com',25,1);
/*!40000 ALTER TABLE `result` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-04-07  9:27:05
