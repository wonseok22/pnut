-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: pnut.cr7lqn4qteql.ap-northeast-2.rds.amazonaws.com    Database: pnut
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_permission` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content_type_id` int NOT NULL,
  `codename` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=153 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` VALUES (1,'Can add log entry',1,'add_logentry'),(2,'Can change log entry',1,'change_logentry'),(3,'Can delete log entry',1,'delete_logentry'),(4,'Can view log entry',1,'view_logentry'),(5,'Can add permission',2,'add_permission'),(6,'Can change permission',2,'change_permission'),(7,'Can delete permission',2,'delete_permission'),(8,'Can view permission',2,'view_permission'),(9,'Can add group',3,'add_group'),(10,'Can change group',3,'change_group'),(11,'Can delete group',3,'delete_group'),(12,'Can view group',3,'view_group'),(13,'Can add user',4,'add_user'),(14,'Can change user',4,'change_user'),(15,'Can delete user',4,'delete_user'),(16,'Can view user',4,'view_user'),(17,'Can add content type',5,'add_contenttype'),(18,'Can change content type',5,'change_contenttype'),(19,'Can delete content type',5,'delete_contenttype'),(20,'Can view content type',5,'view_contenttype'),(21,'Can add session',6,'add_session'),(22,'Can change session',6,'change_session'),(23,'Can delete session',6,'delete_session'),(24,'Can view session',6,'view_session'),(25,'Can add auth group',7,'add_authgroup'),(26,'Can change auth group',7,'change_authgroup'),(27,'Can delete auth group',7,'delete_authgroup'),(28,'Can view auth group',7,'view_authgroup'),(29,'Can add auth group permissions',8,'add_authgrouppermissions'),(30,'Can change auth group permissions',8,'change_authgrouppermissions'),(31,'Can delete auth group permissions',8,'delete_authgrouppermissions'),(32,'Can view auth group permissions',8,'view_authgrouppermissions'),(33,'Can add auth permission',9,'add_authpermission'),(34,'Can change auth permission',9,'change_authpermission'),(35,'Can delete auth permission',9,'delete_authpermission'),(36,'Can view auth permission',9,'view_authpermission'),(37,'Can add auth user',10,'add_authuser'),(38,'Can change auth user',10,'change_authuser'),(39,'Can delete auth user',10,'delete_authuser'),(40,'Can view auth user',10,'view_authuser'),(41,'Can add auth user groups',11,'add_authusergroups'),(42,'Can change auth user groups',11,'change_authusergroups'),(43,'Can delete auth user groups',11,'delete_authusergroups'),(44,'Can view auth user groups',11,'view_authusergroups'),(45,'Can add auth user user permissions',12,'add_authuseruserpermissions'),(46,'Can change auth user user permissions',12,'change_authuseruserpermissions'),(47,'Can delete auth user user permissions',12,'delete_authuseruserpermissions'),(48,'Can view auth user user permissions',12,'view_authuseruserpermissions'),(49,'Can add board',13,'add_board'),(50,'Can change board',13,'change_board'),(51,'Can delete board',13,'delete_board'),(52,'Can view board',13,'view_board'),(53,'Can add board steps',14,'add_boardsteps'),(54,'Can change board steps',14,'change_boardsteps'),(55,'Can delete board steps',14,'delete_boardsteps'),(56,'Can view board steps',14,'view_boardsteps'),(57,'Can add category',15,'add_category'),(58,'Can change category',15,'change_category'),(59,'Can delete category',15,'delete_category'),(60,'Can view category',15,'view_category'),(61,'Can add comment',16,'add_comment'),(62,'Can change comment',16,'change_comment'),(63,'Can delete comment',16,'delete_comment'),(64,'Can view comment',16,'view_comment'),(65,'Can add django admin log',17,'add_djangoadminlog'),(66,'Can change django admin log',17,'change_djangoadminlog'),(67,'Can delete django admin log',17,'delete_djangoadminlog'),(68,'Can view django admin log',17,'view_djangoadminlog'),(69,'Can add django content type',18,'add_djangocontenttype'),(70,'Can change django content type',18,'change_djangocontenttype'),(71,'Can delete django content type',18,'delete_djangocontenttype'),(72,'Can view django content type',18,'view_djangocontenttype'),(73,'Can add django migrations',19,'add_djangomigrations'),(74,'Can change django migrations',19,'change_djangomigrations'),(75,'Can delete django migrations',19,'delete_djangomigrations'),(76,'Can view django migrations',19,'view_djangomigrations'),(77,'Can add django session',20,'add_djangosession'),(78,'Can change django session',20,'change_djangosession'),(79,'Can delete django session',20,'delete_djangosession'),(80,'Can view django session',20,'view_djangosession'),(81,'Can add food',21,'add_food'),(82,'Can change food',21,'change_food'),(83,'Can delete food',21,'delete_food'),(84,'Can view food',21,'view_food'),(85,'Can add food ingre',22,'add_foodingre'),(86,'Can change food ingre',22,'change_foodingre'),(87,'Can delete food ingre',22,'delete_foodingre'),(88,'Can view food ingre',22,'view_foodingre'),(89,'Can add food nut',23,'add_foodnut'),(90,'Can change food nut',23,'change_foodnut'),(91,'Can delete food nut',23,'delete_foodnut'),(92,'Can view food nut',23,'view_foodnut'),(93,'Can add ingredient',24,'add_ingredient'),(94,'Can change ingredient',24,'change_ingredient'),(95,'Can delete ingredient',24,'delete_ingredient'),(96,'Can view ingredient',24,'view_ingredient'),(97,'Can add like',25,'add_like'),(98,'Can change like',25,'change_like'),(99,'Can delete like',25,'delete_like'),(100,'Can view like',25,'view_like'),(101,'Can add nut ingre',26,'add_nutingre'),(102,'Can change nut ingre',26,'change_nutingre'),(103,'Can delete nut ingre',26,'delete_nutingre'),(104,'Can view nut ingre',26,'view_nutingre'),(105,'Can add nut quest',27,'add_nutquest'),(106,'Can change nut quest',27,'change_nutquest'),(107,'Can delete nut quest',27,'delete_nutquest'),(108,'Can view nut quest',27,'view_nutquest'),(109,'Can add nutrient',28,'add_nutrient'),(110,'Can change nutrient',28,'change_nutrient'),(111,'Can delete nutrient',28,'delete_nutrient'),(112,'Can view nutrient',28,'view_nutrient'),(113,'Can add question',29,'add_question'),(114,'Can change question',29,'change_question'),(115,'Can delete question',29,'delete_question'),(116,'Can view question',29,'view_question'),(117,'Can add recipe',30,'add_recipe'),(118,'Can change recipe',30,'change_recipe'),(119,'Can delete recipe',30,'delete_recipe'),(120,'Can view recipe',30,'view_recipe'),(121,'Can add recipe steps',31,'add_recipesteps'),(122,'Can change recipe steps',31,'change_recipesteps'),(123,'Can delete recipe steps',31,'delete_recipesteps'),(124,'Can view recipe steps',31,'view_recipesteps'),(125,'Can add result',32,'add_result'),(126,'Can change result',32,'change_result'),(127,'Can delete result',32,'delete_result'),(128,'Can view result',32,'view_result'),(129,'Can add user',33,'add_user'),(130,'Can change user',33,'change_user'),(131,'Can delete user',33,'delete_user'),(132,'Can view user',33,'view_user'),(133,'Can add user symptom',34,'add_usersymptom'),(134,'Can change user symptom',34,'change_usersymptom'),(135,'Can delete user symptom',34,'delete_usersymptom'),(136,'Can view user symptom',34,'view_usersymptom'),(137,'Can add like table',35,'add_liketable'),(138,'Can change like table',35,'change_liketable'),(139,'Can delete like table',35,'delete_liketable'),(140,'Can view like table',35,'view_liketable'),(141,'Can add food cat',36,'add_foodcat'),(142,'Can change food cat',36,'change_foodcat'),(143,'Can delete food cat',36,'delete_foodcat'),(144,'Can view food cat',36,'view_foodcat'),(145,'Can add nutrient rec',37,'add_nutrientrec'),(146,'Can change nutrient rec',37,'change_nutrientrec'),(147,'Can delete nutrient rec',37,'delete_nutrientrec'),(148,'Can view nutrient rec',37,'view_nutrientrec'),(149,'Can add nutrient question',38,'add_nutrientquestion'),(150,'Can change nutrient question',38,'change_nutrientquestion'),(151,'Can delete nutrient question',38,'delete_nutrientquestion'),(152,'Can view nutrient question',38,'view_nutrientquestion');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-04-07  9:27:02
