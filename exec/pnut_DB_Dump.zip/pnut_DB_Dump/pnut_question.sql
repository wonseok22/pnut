-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: pnut.cr7lqn4qteql.ap-northeast-2.rds.amazonaws.com    Database: pnut
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `question`
--

DROP TABLE IF EXISTS `question`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `question` (
  `question_id` bigint NOT NULL AUTO_INCREMENT,
  `content` varchar(45) DEFAULT NULL,
  `category_id` bigint NOT NULL,
  PRIMARY KEY (`question_id`),
  KEY `fk_servey_category1_idx` (`category_id`),
  CONSTRAINT `fk_servey_category1` FOREIGN KEY (`category_id`) REFERENCES `category` (`category_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `question`
--

LOCK TABLES `question` WRITE;
/*!40000 ALTER TABLE `question` DISABLE KEYS */;
INSERT INTO `question` VALUES (1,'우울한 기분이 자주 들어요.',1),(2,'감정 조절이 힘들어요.',1),(3,'이유 없이 기분이 좋지 않을때가 있어요.',1),(4,'사소한 일에도 스트레스를 많이 받아요.',1),(5,'피부 탄력이 부족한 것 같은 느낌이 들어요.',2),(6,'입술이 건조하고 자주 갈라져요.',2),(7,'피부가 금세 거칠어져요.',2),(8,'피부 노화 예방에 관심이 많아요.',2),(9,'손톱, 발톱이 쉽게 깨지는 경우가 있어요.',2),(10,'치아 건강에 관심이 많아요.',3),(11,'구내염이 자주 생겨요.',3),(12,'잇몸에서 피가 나거나 염증이 생길 때가 있어요.',3),(13,'체중 증가에 관심이 많아요.',4),(14,'체중 감량에 관심이 많아요.',4),(15,'빈혈기가 있어요.',4),(16,'화장실을 잘 가지 못해요.',4),(17,'뼈가 약해진 것 같은 느낌이 있어요.',5),(18,'뼈가 부러져 본 경험이 있어요.',5),(19,'관절염 증세가 있어요.',5),(20,'관절 건강에 관심이 많아요.',5),(21,'무기력하고 식욕이 없어요.',6),(22,'신경이 예민하고 밤에 잠을 이루기 힘들어요.',6),(23,'푹 자고 일어나도 피곤해요.',6),(24,'만성피로가 있어요.',6),(25,'가끔 눈이 파르르 떨려요',6),(26,'술을 자주 마셔요.',7),(27,'소화가 잘 안돼요.',8),(28,'배가 자주 아파요.',8),(29,'모발이 얇아요.',9),(30,'모발이 빠지는 것 같아요',9),(31,'모발에 윤기와 탄력이 없어요.',9),(32,'두피에 뾰루지나 염증이 잘 생겨요',9),(33,'모발이 뚝뚝 끊겨요.',9),(34,'모발이 건조해요',9),(35,'위경련을 겪은 적이 있어요.',10),(36,'고기 위주의 식사를 주로 해요',10),(37,'밥을 먹고 속이 불편한 적이 있어요.',10),(38,'감기에 자주 걸리는 편이에요.',11),(39,'야외활동을 자주 하지 않아요.',11),(40,'입술이나 입 주변에 물집이 자주 생겨요',11),(41,'면역력 보강에 관심이 많아요.',11);
/*!40000 ALTER TABLE `question` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-04-07  9:27:08
