-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: pnut.cr7lqn4qteql.ap-northeast-2.rds.amazonaws.com    Database: pnut
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `board`
--

DROP TABLE IF EXISTS `board`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `board` (
  `board_id` bigint NOT NULL AUTO_INCREMENT,
  `user_email` varchar(50) NOT NULL,
  `content` text,
  `create_date` datetime DEFAULT NULL,
  `visit` int NOT NULL DEFAULT '0',
  `thumbnail_image_url` varchar(100) DEFAULT NULL,
  `title` varchar(30) DEFAULT NULL,
  `ingredients` varchar(200) DEFAULT NULL,
  `time` int DEFAULT NULL,
  `quantity` int DEFAULT NULL,
  `likes` int DEFAULT '0',
  PRIMARY KEY (`board_id`),
  KEY `fk_board_user1_idx` (`user_email`),
  CONSTRAINT `fk_board_user1` FOREIGN KEY (`user_email`) REFERENCES `user` (`email`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `board`
--

LOCK TABLES `board` WRITE;
/*!40000 ALTER TABLE `board` DISABLE KEYS */;
INSERT INTO `board` VALUES (31,'jleejlee6@gmail.com','간단한 김치볶음밥 레시피입니다.\n\n누구나 따라할 수 있어요!','2023-04-06 13:54:33',63,'ace97095-c205-4e28-94de-77ca9751ff36.jpg','초간단 김치볶음밥 이제 여기에 존맛을 곁들인','김치1 종이컵, 밥 1공기(햇반 하나도 가능), 대파 1대, 달걀 1개,  설탕, 간장, 고춧가루 1/3스푼, ',1,1,6),(32,'gkagu12@naver.com','일본 정통 가정식 중 하나인 돼지조림 요리입니다!','2023-04-06 15:58:24',58,'9572d4bb-62ae-4df7-9229-689c5925dd56.JPG','부타노가쿠니','삼겹살 수육 커팅 2kg, 대파 초록부분 4~5대, 생강 1뿌리, 가쓰오부시 육수 1.5리터, 청주 200g, 미림 100g, 황설탕 50g, 진간장 50g, 타마리간장 25g',3,3,4),(44,'minofficial13@gmail.com','마제소바 레시피 두반장, 쯔유 대신 흔한 재료 이거 넣었어요','2023-04-07 00:41:24',7,'25fa49ca-b6f1-4ead-97d6-3ecf9b92b6b9.jpg','마제소바','우동면, 대파, 부추, 계란노른자, 다진 돼지고기, 김가루',1,2,0),(46,'minofficial@naver.com','마제소바 레시피 두반장, 쯔유 대신 흔한 재료 이거 넣었어요','2023-04-07 00:55:28',8,'1a90717f-d7cd-4b76-8a6b-3cdd4cb9afd9.jpg','마제소바','우동면, 대파, 부추, 계란노른자, 다진 돼지고기, 김가루',1,2,0),(47,'tlsdnrng@gmail.com','100만원','2023-04-07 00:57:17',5,'f4c55e42-ad6d-4dc8-b6a2-8a994d0b9a79.png','교육지원금','레츠고',3,2,0),(48,'tlsdnrng@gmail.com','없음 ㅋ','2023-04-07 01:18:57',2,'df1f59db-0c33-4d00-8fb1-3e63522a9270.png','이벤트 루프를 맛있게 먹는 법','JS, VScode',3,3,0),(51,'tlsdnrng@gmail.com','없음 ㅠ','2023-04-07 01:34:47',2,'fdb0198f-f9ba-4f08-b706-4788cdd912c6.png','자바스크립트를 아이스크림처럼 쉽게 먹는법','vscode',3,3,0),(52,'withfavor98@naver.com','라면국물을 졸여서 계란과 야채, 치즈를 얹어먹는 요리','2023-04-07 01:36:46',4,'3af11a21-f502-4111-a927-0374ebb943fb.PNG','쿠지라이식 라면','라면, 계란, 치즈, 야채',0,1,0),(53,'minofficial13@gmail.com','마제소바 레시피 두반장, 쯔유 대신 흔한 재료 이거 넣었어요','2023-04-07 01:38:39',1,'d26b7e95-4d38-4bf4-b86c-02dd4c3f75cc.jpg','마제소바','우동면, 대파, 부추, 계란노른자, 다진 돼지고기, 김가루',1,2,0),(54,'minofficial@naver.com','진짜임 ㄷㄷ','2023-04-07 01:40:44',1,'b37daab1-1c06-416d-8091-da4d1a47a992.jpg','강신욱바보','강신욱, 바보',1,2,0),(55,'tlsdnrng@gmail.com','ㅇㅇ','2023-04-07 01:42:42',2,'c34e0a23-99ad-4f6f-b71e-a02593a7bdc5.png','자고싶다','ㅇㅇ',3,2,0),(56,'withfavor98@naver.com','겁나 맛있는 구운고기','2023-04-07 01:43:37',3,'d8085b35-671a-4677-99e3-cb35a4f86860.jpeg','스테이꾸','고기, 후추, 소금',1,1,0),(57,'tlsdnrng@gmail.com','네','2023-04-07 01:45:41',3,'fc207424-ef8e-4486-a5a5-f06856e8b3ea.png','1입니다','1이에요',3,4,0),(58,'withfavor98@naver.com','스테이','2023-04-07 01:52:32',1,'156e537a-afcc-4f58-9ca3-e3ecbd36bfb7.PNG','꼬기','양파, 간장, 굴소스, 다진고기',1,1,0),(59,'minofficial@naver.com','import React, { createRef, useRef, useState, useEffect } from \"react\";\nimport ArticleImgBlock from \"../Components/ArticleImgBlock\";\nimport newpostAPI from \"../api/newpostAPI\";\nimport { useSelector } from \"react-redux\";\nimport { useNavigateToTop } from \"..','2023-04-07 01:57:30',4,'446a5583-5544-43ac-a002-16156f103a65.jpg','마제소바','git reset --hard HEAD',1,2,0),(60,'tlsdnrng@gmail.com','2345','2023-04-07 01:59:56',2,'749f0cbd-8c1b-43c8-bf88-4c494f3cb56a.png','2345','2345',2,1,0),(61,'tlsdnrng@gmail.com','그런건','2023-04-07 02:01:50',1,'05b60f20-2974-4111-a296-f8ef71c0cffb.png','JS를 케이크처럼 쉽게 먹는 법','없어용~',2,3,0),(62,'tlsdnrng@gmail.com','234','2023-04-07 02:02:39',1,'10a74cb6-59c0-4682-ab4f-5e0f895e59d9.png','1','234646',2,4,0),(63,'minofficial@naver.com','ㅁ냠','2023-04-07 02:03:14',1,'2d0310c0-82bd-4fea-a9a0-b91e5c729677.jpg','고기보끔ㄷㄷ','ㅁㄴㅇㄹ',1,1,0),(64,'tlsdnrng@gmail.com','241235','2023-04-07 02:04:44',0,'35143bd2-ab58-4e2a-92a8-e665cd84a638.png','1 1트','3245',0,1,0),(65,'tlsdnrng@gmail.com','123','2023-04-07 02:09:10',0,'e1370f44-b51a-4d81-bb38-2879d61bc6cc.png','1 2트','234',2,1,0),(66,'tlsdnrng@gmail.com','4ㅅㄱ35','2023-04-07 02:11:28',8,'c0b1d316-ef2f-4b39-a86c-3473b78413d3.png','1 3트','456',2,2,0);
/*!40000 ALTER TABLE `board` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-04-07  9:27:13
